package prototyp;

import java.util.Scanner;

public class Kinobuchungssystem {
	public Sammlung s = new Sammlung();
	
	
	public Kinobuchungssystem() {
		
	}
	
	public void reservierungSperichern(Reservierung reservierung) {
		
	}
	
	public void registerBesucher(Besucher besucher) {
		
	}
	
	
}
