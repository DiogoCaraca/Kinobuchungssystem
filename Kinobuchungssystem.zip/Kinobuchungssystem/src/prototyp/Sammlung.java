package prototyp;

import java.util.ArrayList;

public class Sammlung {
	public ArrayList<Kinosaal> kinosaale = new ArrayList<Kinosaal>();
	public ArrayList<Besucher> besucher = new ArrayList<Besucher>();
	public ArrayList<Vorstellung> vorsellungen = new ArrayList<Vorstellung>();
	public ArrayList<Reservierung> reservierungen = new ArrayList<Reservierung>();
	
	public Sammlung() {
		
		
	}
	
	
	
	
}
