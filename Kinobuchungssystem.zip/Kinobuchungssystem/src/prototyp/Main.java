package prototyp;

public class Main {

	public static void main(String[] args) {
		
		StartApp str = new StartApp();
		str.menu();

	}

}
