package prototyp;

import java.util.ArrayList;

public class Kinosaal {
	ArrayList<Reihe> reihen = new ArrayList<Reihe>();
	
	public Kinosaal() {
		
	}
	
	public Kinosaal(ArrayList<Reihe> reihen) {
		
	}
	
	public void add(Reihe reihe) {
		
	}

	
}
